create function st_setbandnodatavalue(rast raster, nodatavalue double precision)
  returns raster
language sql
as $$
SELECT public.ST_setbandnodatavalue($1, 1, $2, FALSE)
$$;

comment on function st_setbandnodatavalue(rast raster, nodatavalue double precision)
is 'args: rast, nodatavalue - Sets the value for the given band that represents no data. Band 1 is assumed if no band is specified. To mark a band as having no nodata value, set the nodata value = NULL.';

