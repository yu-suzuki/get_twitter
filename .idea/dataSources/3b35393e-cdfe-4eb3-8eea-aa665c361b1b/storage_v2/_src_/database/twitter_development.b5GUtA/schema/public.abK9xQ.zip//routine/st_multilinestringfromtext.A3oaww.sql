create function st_multilinestringfromtext(text)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_MLineFromText($1)
$$;

